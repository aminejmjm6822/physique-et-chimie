import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Users, Clock, Award } from 'lucide-react';

const features = [
  {
    icon: <BookOpen className="h-8 w-8" />,
    title: "Cours Interactifs",
    description: "Apprenez avec des cours dynamiques et interactifs"
  },
  {
    icon: <Users className="h-8 w-8" />,
    title: "Professeurs Qualifiés",
    description: "Une équipe d'experts à votre service"
  },
  {
    icon: <Clock className="h-8 w-8" />,
    title: "Flexibilité Horaire",
    description: "Étudiez à votre rythme, 24/7"
  },
  {
    icon: <Award className="h-8 w-8" />,
    title: "Suivi Personnalisé",
    description: "Un accompagnement adapté à vos besoins"
  }
];

export const WhyChooseUs = () => {
  return (
    <section className="py-16 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-3xl font-bold text-center mb-12 dark:text-white"
        >
          Pourquoi Nous Choisir ?
        </motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="p-6 bg-gray-50 dark:bg-gray-800 rounded-xl text-center"
            >
              <div className="mb-4 text-blue-600 dark:text-blue-400 flex justify-center">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2 dark:text-white">
                {feature.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-300">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};