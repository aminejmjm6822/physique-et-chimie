import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronUp } from 'lucide-react';

const faqs = [
  {
    question: "Comment s'inscrire aux cours ?",
    answer: "L'inscription se fait directement en ligne. Sélectionnez votre niveau et les cours qui vous intéressent, puis suivez les étapes d'inscription."
  },
  {
    question: "Les cours sont-ils disponibles en ligne ?",
    answer: "Oui, tous nos cours sont accessibles en ligne 24h/24 et 7j/7. Vous pouvez les suivre à votre rythme depuis n'importe quel appareil."
  },
  {
    question: "Y a-t-il un suivi personnalisé ?",
    answer: "Absolument ! Chaque étudiant bénéficie d'un suivi personnalisé avec nos professeurs qui répondent à vos questions et suivent votre progression."
  },
  {
    question: "Comment se déroulent les examens ?",
    answer: "Les examens sont organisés en ligne avec des QCM et des exercices pratiques. Des sessions de révision sont également proposées avant chaque examen."
  }
];

export const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 dark:text-white">
          Questions Fréquentes
        </h2>
        <div className="max-w-3xl mx-auto space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full px-6 py-4 text-left flex justify-between items-center"
              >
                <span className="font-semibold dark:text-white">{faq.question}</span>
                {openIndex === index ? (
                  <ChevronUp className="h-5 w-5 text-blue-600" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-blue-600" />
                )}
              </button>
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="px-6 py-4 border-t dark:border-gray-700"
                  >
                    <p className="text-gray-600 dark:text-gray-300">{faq.answer}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};