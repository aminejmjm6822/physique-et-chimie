import React from 'react';
import { Beaker, BookOpen, Calendar, GraduationCap, Search, ChevronRight, Star, MapPin, Menu, FlaskRound as Flask, Calculator, Atom } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navbar */}
      <nav className="bg-white shadow-md fixed w-full z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Beaker className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-800">PhysiqueChimie</span>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <a href="#" className="text-gray-600 hover:text-blue-600">Accueil</a>
              <a href="#" className="text-gray-600 hover:text-blue-600">Cours</a>
              <a href="#" className="text-gray-600 hover:text-blue-600">Niveaux</a>
              <a href="#" className="text-gray-600 hover:text-blue-600">Contact</a>
              
              <div className="relative">
                <input
                  type="text"
                  placeholder="Rechercher un cours..."
                  className="pl-10 pr-4 py-2 rounded-full border border-gray-300 focus:outline-none focus:border-blue-500"
                />
                <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
            </div>
            
            <button className="md:hidden">
              <Menu className="h-6 w-6 text-gray-600" />
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-12 bg-gradient-to-br from-blue-50 to-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Apprenez la Physique et la Chimie Différemment
              </h1>
              <p className="text-xl text-gray-600 mb-6">
                Des cours interactifs et personnalisés pour tous les niveaux
              </p>
              <div className="flex space-x-4">
                <button className="bg-blue-600 text-white px-8 py-3 rounded-full hover:bg-blue-700 transition">
                  Commencer
                </button>
                <button className="border border-blue-600 text-blue-600 px-8 py-3 rounded-full hover:bg-blue-50 transition">
                  Découvrir les cours
                </button>
              </div>
            </div>
            <div className="md:w-1/2">
              <img 
                src="https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=800&q=80" 
                alt="Professor teaching"
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Levels Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Niveaux d'études</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                title: "Tronc Commun",
                icon: <GraduationCap className="h-8 w-8" />,
                color: "bg-green-500",
                description: "Formation fondamentale en sciences physiques"
              },
              {
                title: "1ère Bac Sciences Expérimentales",
                icon: <Flask className="h-8 w-8" />,
                color: "bg-blue-500",
                description: "Spécialisation en sciences expérimentales"
              },
              {
                title: "1ère Bac Sciences Mathématiques",
                icon: <Calculator className="h-8 w-8" />,
                color: "bg-purple-500",
                description: "Approche mathématique approfondie"
              },
              {
                title: "2ème Bac Physique-Chimie",
                icon: <Atom className="h-8 w-8" />,
                color: "bg-red-500",
                description: "Programme avancé de physique-chimie"
              }
            ].map((level, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition-transform duration-300">
                <div className={`${level.color} p-6 flex justify-center text-white`}>
                  {level.icon}
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-semibold mb-2 text-center">{level.title}</h3>
                  <p className="text-gray-600 text-center text-sm">{level.description}</p>
                  <button className="mt-4 w-full flex items-center justify-center text-blue-600 hover:text-blue-700">
                    Voir le programme
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Course Grid */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Nouveaux Cours</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Mécanique Quantique",
                level: "2ème Bac",
                icon: <BookOpen className="h-6 w-6" />,
                color: "bg-blue-500"
              },
              {
                title: "Chimie Organique",
                level: "1ère Bac",
                icon: <Beaker className="h-6 w-6" />,
                color: "bg-red-500"
              },
              {
                title: "Électromagnétisme",
                level: "Tronc Commun",
                icon: <GraduationCap className="h-6 w-6" />,
                color: "bg-purple-500"
              }
            ].map((course, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden">
                <div className={`${course.color} p-4 text-white`}>
                  {course.icon}
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{course.title}</h3>
                  <p className="text-gray-600 mb-4">{course.level}</p>
                  <button className="flex items-center text-blue-600 hover:text-blue-700">
                    Voir le cours
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Ce que disent nos étudiants</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((_, index) => (
              <div key={index} className="bg-white p-6 rounded-xl shadow-lg">
                <div className="flex items-center mb-4">
                  <img
                    src={`https://i.pravatar.cc/150?img=${index + 1}`}
                    alt="Student"
                    className="w-12 h-12 rounded-full"
                  />
                  <div className="ml-4">
                    <h4 className="font-semibold">Étudiant {index + 1}</h4>
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600">
                  "Les cours sont très bien structurés et les professeurs sont excellents. J'ai beaucoup progressé grâce à cette plateforme."
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Events */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Prochains Événements</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                title: "Workshop de Chimie",
                date: "15 Mars 2024",
                location: "Centre Rabat"
              },
              {
                title: "Préparation Bac",
                date: "20 Mars 2024",
                location: "Centre Casablanca"
              }
            ].map((event, index) => (
              <div key={index} className="flex items-start p-6 bg-gray-50 rounded-xl">
                <Calendar className="h-12 w-12 text-blue-600 flex-shrink-0" />
                <div className="ml-4">
                  <h3 className="text-xl font-semibold mb-2">{event.title}</h3>
                  <p className="text-gray-600 mb-1">{event.date}</p>
                  <p className="flex items-center text-gray-600">
                    <MapPin className="h-4 w-4 mr-1" />
                    {event.location}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <Beaker className="h-8 w-8 text-blue-400" />
                <span className="ml-2 text-xl font-bold">PhysiqueChimie</span>
              </div>
              <p className="text-gray-400">
                La meilleure plateforme pour apprendre la physique et la chimie.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Centres</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Rabat - Hassan</li>
                <li>Casablanca - Maarif</li>
                <li>Tanger - Centre</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact</h3>
              <ul className="space-y-2 text-gray-400">
                <li>+212 5XX-XXXXXX</li>
                <li>contact@physiquechimie.ma</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Horaires</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Lun - Ven: 8h - 20h</li>
                <li>Sam: 9h - 18h</li>
                <li>Dim: Fermé</li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;